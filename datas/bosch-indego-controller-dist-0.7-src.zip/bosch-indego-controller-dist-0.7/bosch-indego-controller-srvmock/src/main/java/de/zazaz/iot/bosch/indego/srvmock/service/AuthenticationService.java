package de.zazaz.iot.bosch.indego.srvmock.service;

public interface AuthenticationService {
    
    public String authenticate(String username, String password);

}
