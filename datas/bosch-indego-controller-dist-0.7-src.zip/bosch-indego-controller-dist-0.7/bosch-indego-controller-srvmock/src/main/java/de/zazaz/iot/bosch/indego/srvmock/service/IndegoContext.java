package de.zazaz.iot.bosch.indego.srvmock.service;

public interface IndegoContext {

    String getUserId ();

    String getDeviceSerial ();

    String getContext ();

}
