package de.zazaz.iot.bosch.indego.srvmock.webservice;

public class IndegoWebConstants {
    
    public static final String HEADER_AUTHORIZATION = "Authorization";
    
    public static final String HEADER_CONTEXT_ID = "x-im-context-id";

}
