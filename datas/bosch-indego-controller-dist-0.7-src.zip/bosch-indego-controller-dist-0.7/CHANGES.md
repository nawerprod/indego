Version 0.1
-------------------------------
* Initial release


Version 0.2
-------------------------------
* Restructured source code
* First release with sources
* Added Mqtt-Adapter


Version 0.3
-------------------------------
* New status field "error"
* Fixed: Reading status if Indego is in error state


Version 0.4
-------------------------------
* Added IFTTT interface


Version 0.5
-------------------------------
* Added protocol description
* IFTTT interface: stability fix


Version 0.6
-------------------------------
* Minor corrections in PROTOCOL.txt
* Moved source to Github

Version 0.7
-------------------------------
* Added: querying the device calendar
* Added some more operations to protocol descriptions
* Added: The base url of web service can be set
* Added: First version of mock service, which simulates the Bosch webservice for testing